import org.junit.Assert;
import org.junit.Test;

public class AppTest {

    @Test
    public void appTest()
    {
        Assert.assertTrue(true);
    }
}
